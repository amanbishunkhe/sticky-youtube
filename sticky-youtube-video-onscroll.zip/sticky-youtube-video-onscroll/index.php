<?php
// Silence is gold